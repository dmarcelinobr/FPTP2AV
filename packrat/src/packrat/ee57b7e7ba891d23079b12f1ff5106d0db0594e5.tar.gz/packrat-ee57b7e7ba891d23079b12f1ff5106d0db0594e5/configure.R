#!/usr/bin/env Rscript

library(utils)
source("R/update.R")
updateInit()
